/* Apellido y nombre :RUGNIA CARLOS MARTIN
DNI: 28337376 
TP3 : POO 
 */
package Clases;

public class PagoConTarjeta extends Pago {

    @Override
    public void procesarPago() {
        System.out.println("Procesando pago con tarjeta...");
    }
}
